SELECT Count(DISTINCT T.Planet_Name ) FROM TimeTable T
WHERE T.Character_Name  = "Luke Skywalker" AND T.Movie = 2;
